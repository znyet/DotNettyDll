﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SuperSocket.Facility.Protocol;
using SuperSocket.SocketBase.Protocol;
using SuperSocket.Common;

namespace TestSuperSocket2
{
    public class MyReceiveFilter : FixedHeaderReceiveFilter<BinaryRequestInfo>
    {
        public MyReceiveFilter()
            : base(4) //固定前面4个字节
        {

        }

        protected override int GetBodyLengthFromHeader(byte[] header, int offset, int length)
        {
            int length2 = BitConverter.ToInt32(header, offset); //把前面4个字节计算成int类型
            return length2;
        }

        protected override BinaryRequestInfo ResolveRequestInfo(ArraySegment<byte> header, byte[] bodyBuffer, int offset, int length)
        {
            string key = BitConverter.ToInt32(header.Array, header.Offset).ToString();
            return new BinaryRequestInfo(key, bodyBuffer.CloneRange(offset, length));
        }
    }
}
