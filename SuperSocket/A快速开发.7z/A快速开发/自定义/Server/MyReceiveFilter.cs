﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SuperSocket.SocketBase.Protocol;

namespace TestSuperSocket3
{
    public class MyReceiveFilter : IReceiveFilter<MyRequestInfo>
    {
        public MyRequestInfo Filter(byte[] readBuffer, int offset, int length, bool toBeCopied, out int rest)
        {
            rest = 0;
            if (length == 0)
                return null;
            else
            {
                MyRequestInfo info = new MyRequestInfo();
                info.data = readBuffer.Skip(offset).Take(length).ToArray();
                return info;
            }
        }

        public int LeftBufferSize
        {
            get { return 0; }
        }

        public IReceiveFilter<MyRequestInfo> NextReceiveFilter
        {
            get { return this; }
        }

        public void Reset()
        {
            
        }

        public FilterState State { get; private set; }
    }
}
