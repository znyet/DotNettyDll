﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SuperSocket.SocketBase;
using SuperSocket.SocketBase.Protocol;

namespace TestSuperSocket3
{
    public class MyAppServer : AppServer<MyAppSession, MyRequestInfo>
    {
        public MyAppServer()
            : base(new DefaultReceiveFilterFactory<MyReceiveFilter, MyRequestInfo>())
        {

        }
    }
}
