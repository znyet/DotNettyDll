﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SuperSocket.SocketBase;
using SuperSocket.SocketBase.Config;
using SuperSocket.WebSocket;

namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {

            var config = new ServerConfig()
            {
                //Name = "SSServer",
                //ServerTypeName = "SServer",
                ClearIdleSession = true, //60秒执行一次清理90秒没数据传送的连接
                ClearIdleSessionInterval = 60,
                IdleSessionTimeOut = 90,
                MaxRequestLength = 2048, //最大包长度
                Ip = "Any",
                Port = 8123,
                MaxConnectionNumber = 100000,
                Mode = SocketMode.Tcp
            };

            var server = new MyServer();
            server.Setup(config);
            server.Start();
            Console.WriteLine("tcp server listen in port:" + 8123);


            //websocket

            var config2 = new ServerConfig()
            {
                //Name = "SSServer",
                //ServerTypeName = "SServer",
                ClearIdleSession = true, //60秒执行一次清理90秒没数据传送的连接
                ClearIdleSessionInterval = 60,
                IdleSessionTimeOut = 90,
                MaxRequestLength = 2048, //最大包长度
                Ip = "Any",
                Port = 8124,
                MaxConnectionNumber = 100000,
                Mode = SocketMode.Tcp
            };

            var webscoketServer = new WebSocketServer();
            webscoketServer.Setup(config2);
            webscoketServer.Start();
            Console.WriteLine("webscoket server listen in port:" + 8124);
            webscoketServer.SessionClosed += webscoketServer_SessionClosed;
            webscoketServer.NewSessionConnected += webscoketServer_NewSessionConnected;
            webscoketServer.NewDataReceived += webscoketServer_NewDataReceived;
            webscoketServer.NewMessageReceived += webscoketServer_NewMessageReceived;

            Console.ReadKey();
        }

        static void webscoketServer_NewMessageReceived(WebSocketSession session, string value)
        {
            throw new NotImplementedException();
        }

        static void webscoketServer_NewDataReceived(WebSocketSession session, byte[] value)
        {
            throw new NotImplementedException();
        }

        static void webscoketServer_NewSessionConnected(WebSocketSession session)
        {
            throw new NotImplementedException();
        }

        static void webscoketServer_SessionClosed(WebSocketSession session, CloseReason value)
        {
            throw new NotImplementedException();
        }
    }
}




//Name = serverName,
//MaxConnectionNumber = 10000, //最大允许的客户端连接数目，默认为100。
//Mode = SocketMode.Tcp,
//Port = port, //服务器监听的端口。
//ClearIdleSession = false,   //true或者false， 是否清除空闲会话，默认为false。
//ClearIdleSessionInterval = 120,//清除空闲会话的时间间隔，默认为120，单位为秒。
//ListenBacklog = 10,
//ReceiveBufferSize = 64 * 1024, //用于接收数据的缓冲区大小，默认为2048。
//SendBufferSize = 64 * 1024,   //用户发送数据的缓冲区大小，默认为2048。
//KeepAliveInterval = 1,     //keep alive消息发送时间间隔。单位为秒。
//KeepAliveTime = 60,    //keep alive失败重试的时间间隔。单位为秒。
//SyncSend = false
