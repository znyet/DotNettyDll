﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SuperSocket.SocketBase;
using SuperSocket.SocketBase.Protocol;

namespace TestSuperSocket2
{
    public class MyAppServer : AppServer<MyAppSession, BinaryRequestInfo>
    {
        public MyAppServer(): base(new DefaultReceiveFilterFactory<MyReceiveFilter, BinaryRequestInfo>())
        {

        }
    }
}
