﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SuperSocket.ClientEngine;
using WebSocket4Net;

namespace ws
{
    class Program
    {
        private static WebSocket websocket;
        static void Main(string[] args)
        {
            websocket = new WebSocket("ws://localhost:8124/");
            websocket.Opened += websocket_Opened;
            websocket.Error += websocket_Error;
            websocket.Closed += websocket_Closed;
            websocket.MessageReceived += websocket_MessageReceived;
            websocket.Open();

            Console.ReadKey();
        }

        static void websocket_MessageReceived(object sender, MessageReceivedEventArgs e)
        {
            
            Console.WriteLine("MessageReceived" + e.Message);
        }

        static void websocket_Closed(object sender, EventArgs e)
        {
            Console.WriteLine("Closed");
        }

        static void websocket_Error(object sender, ErrorEventArgs e)
        {
            Console.WriteLine("Error");
        }

        static void websocket_Opened(object sender, EventArgs e)
        {
            websocket.Send("你好啊");
            Console.WriteLine("Opened");
        }
    }
}
