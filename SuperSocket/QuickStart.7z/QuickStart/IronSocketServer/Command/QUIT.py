﻿def execute(session, request):
	session.Close()