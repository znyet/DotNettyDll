﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SuperSocket.SocketBase.Protocol;

namespace TestSuperSocket3
{
    public class MyRequestInfo : IRequestInfo
    {
        public string Key
        {
            get { return ""; }
        }

        public byte[] data { get; set; }
    }
}
