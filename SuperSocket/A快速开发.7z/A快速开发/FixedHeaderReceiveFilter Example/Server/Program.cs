﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SuperSocket.SocketBase.Config;
using SuperSocket.SocketBase;
using SuperSocket.SocketBase.Protocol;

namespace TestSuperSocket2
{
    class Program
    {
        static MyAppServer server = new MyAppServer();
        static void Main(string[] args)
        {
            var config = new ServerConfig
            {
                Port = 6666, //set the listening port
                Ip = "Any",
                Name = "XHS_Server",
                //Other configuration options
                Mode = SocketMode.Tcp,
                MaxConnectionNumber = 100000,
                IdleSessionTimeOut = 600,
                TextEncoding = "UTF-8",
                SyncSend = true,
                SendBufferSize = 1024,
                ReceiveBufferSize = 1024,
                LogBasicSessionActivity = true,
                LogAllSocketException = true,
                KeepAliveTime = 300
            };

            server.Setup(config);
            server.NewSessionConnected += new SessionHandler<MyAppSession>(appServer_NewSessionConnected);

            //若是使用Command命令，则要移除此方法
            server.NewRequestReceived += new RequestHandler<MyAppSession, BinaryRequestInfo>(appServer_NewRequestReceived);
            server.SessionClosed += new SessionHandler<MyAppSession, SuperSocket.SocketBase.CloseReason>(appServer_SessionClosed);
            server.Start();

            Console.WriteLine("listening port 666....");
            Console.ReadKey();
        }

        static void appServer_NewSessionConnected(MyAppSession session)
        {
            Console.WriteLine("有新的连接...");
        }

        static void appServer_NewRequestReceived(MyAppSession session, BinaryRequestInfo requestInfo)
        {
            Console.WriteLine(requestInfo.Key);
            string body = Encoding.UTF8.GetString(requestInfo.Body);
            Console.WriteLine(body);
        }


        static void appServer_SessionClosed(MyAppSession session, SuperSocket.SocketBase.CloseReason closereason)
        {
            Console.WriteLine("断开连接...");

        }
    }
}
