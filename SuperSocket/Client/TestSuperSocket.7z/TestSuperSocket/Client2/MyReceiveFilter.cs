﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SuperSocket.ProtoBase;

namespace Client2
{
    class MyReceiveFilter : FixedHeaderReceiveFilter<MyPackageInfo>
    {
        public MyReceiveFilter()
            : base(4)
        {

        }

        protected override int GetBodyLengthFromHeader(IBufferStream bufferStream, int length)
        {
            var buffers = bufferStream.Buffers[0];

            var headBytes = buffers.Array.Skip(buffers.Offset).Take(buffers.Count).ToArray();
            int len = BitConverter.ToInt32(headBytes.Reverse().ToArray(), 0);
            Console.WriteLine(len);
            return len;
        }

        public override MyPackageInfo ResolvePackage(IBufferStream bufferStream)
        {
            var headBuffer = bufferStream.Buffers[0];
            var bodyBuffer = bufferStream.Buffers[1];

            var headBytes = headBuffer.Array.Skip(headBuffer.Offset).Take(headBuffer.Count).ToArray();
            var bodyBytes = bodyBuffer.Array.Skip(bodyBuffer.Offset).Take(bodyBuffer.Count).ToArray();

            return new MyPackageInfo(headBytes, bodyBytes);
        }


    }
}



//TerminatorReceiveFilter
//BeginEndMarkReceiveFilter
//FixedHeaderReceiveFilter
//FixedSizeReceiveFilter
//CountSpliterReceiveFilter