﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SuperSocket.SocketBase;
using SuperSocket.SocketBase.Protocol;

namespace TestSuperSocket
{
    public class MyAppServer : AppServer<MyAppSession>
    {
        public MyAppServer(): base(new TerminatorReceiveFilterFactory("##")) //以##为结束符号
        {

        }

    }
}
