﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SuperSocket.SocketBase;
using SuperSocket.SocketBase.Protocol;

namespace TestSuperSocket
{
    public class MyAppSession : AppSession<MyAppSession>
    {
        //记录日志
        protected override void HandleUnknownRequest(StringRequestInfo cmdInfo)
        {
            Logger.Error("AppSession Unknow request");
        }

        protected override void HandleException(Exception e)
        {
            Logger.Error(e.Message);
        }
    }
}
