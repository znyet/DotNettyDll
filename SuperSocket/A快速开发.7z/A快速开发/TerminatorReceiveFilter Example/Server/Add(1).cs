﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SuperSocket.SocketBase.Command;
using SuperSocket.SocketBase.Protocol;

namespace TestSuperSocket
{
    public class Add : CommandBase<MyAppSession, StringRequestInfo>
    {
        public override void ExecuteCommand(MyAppSession session, StringRequestInfo requestInfo)
        {
            Console.WriteLine("使用Command方法输出命令");
            Console.WriteLine(requestInfo.Key);
            Console.WriteLine(requestInfo.Body);
        }
    }
}
