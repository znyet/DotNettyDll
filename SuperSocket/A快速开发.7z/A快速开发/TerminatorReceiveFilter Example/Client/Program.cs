﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SuperSocket.ClientEngine;
using System.Net;

namespace TestSuperSocketClient
{
    class Program
    {
        static AsyncTcpSession client;
        static void Main(string[] args)
        {
            IPAddress ipAddress = IPAddress.Parse("127.0.0.1");//把ip地址字符串转换为IPAddress类型的实例
            IPEndPoint ipe = new IPEndPoint(ipAddress, 6666);//用指定的端口和ip初始化   
            client = new AsyncTcpSession();


            client.Connected += new EventHandler(Connected);
            client.Closed += new EventHandler(Closed);
            client.Error += new EventHandler<ErrorEventArgs>(Error);
            client.DataReceived += new EventHandler<DataEventArgs>(DataReceived);

            client.Connect(ipe);
            Console.ReadKey();
        }

        static void Connected(object sender, EventArgs e)
        {
            Console.WriteLine("成功连接服务器");

            byte[] b = Encoding.UTF8.GetBytes("key value##");

            client.Send(b, 0, b.Length);
        }

        static void Closed(object sender, EventArgs e)
        {
            Console.WriteLine("断开服务器连接");
        }

        static void Error(object sender, ErrorEventArgs e)
        {
            Console.WriteLine("发生错误了");
        }

        static void DataReceived(object sender, DataEventArgs e)
        {
            string data = Encoding.UTF8.GetString(e.Data);
            Console.WriteLine(data);
        }
    }
}
