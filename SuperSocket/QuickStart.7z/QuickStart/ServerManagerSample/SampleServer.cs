﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SuperSocket.SocketBase;

namespace SuperSocket.QuickStart.ServerManagerSample
{
    public class SampleServer : AppServer
    {

    }
}
