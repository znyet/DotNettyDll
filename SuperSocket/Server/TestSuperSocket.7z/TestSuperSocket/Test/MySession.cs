﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SuperSocket.SocketBase;
using SuperSocket.SocketBase.Protocol;

namespace Test
{
    public class MySession : AppSession<MySession,BinaryRequestInfo>
    {

        protected override void OnSessionStarted()
        {
            Console.WriteLine("OnSessionStarted");
            base.OnSessionStarted();
        }


        protected override void HandleException(Exception e)
        {
            Console.WriteLine("HandleException");
            base.HandleException(e);
        }

        protected override void HandleUnknownRequest(BinaryRequestInfo requestInfo)
        {
            Console.WriteLine("HandleUnknownRequest");
            base.HandleUnknownRequest(requestInfo);
        }

        protected override void OnSessionClosed(CloseReason reason)
        {
            Console.WriteLine("OnSessionClosed");
            base.OnSessionClosed(reason);
        }

    }
}
