﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SuperSocket.SocketBase;
using SuperSocket.SocketBase.Protocol;

namespace TestSuperSocket2
{
    public class MyAppSession : AppSession<MyAppSession, BinaryRequestInfo>
    {
        protected override void HandleException(Exception e)
        {
            Console.WriteLine("HandleException");
        }
    }
}
