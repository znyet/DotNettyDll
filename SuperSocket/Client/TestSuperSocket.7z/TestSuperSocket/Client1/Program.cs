﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using SuperSocket.ClientEngine;

namespace Client1
{
    class Program
    {
        static void Main(string[] args)
        {
            var client = new AsyncTcpSession();
            client.Connected += client_Connected;
            client.DataReceived += client_DataReceived;
            client.Closed += client_Closed;
            client.Error += client_Error;

            var endPoint = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8123);
            client.Connect(endPoint);

            Console.ReadKey();
        }

        static void client_Error(object sender, ErrorEventArgs e)
        {
            Console.WriteLine("Error");
        }

        static void client_Closed(object sender, EventArgs e)
        {
            Console.WriteLine("Closed");
        }

        static void client_DataReceived(object sender, DataEventArgs e)
        {
            Console.WriteLine("DataReceived");
        }

        static void client_Connected(object sender, EventArgs e)
        {
            Console.WriteLine("Connected");
        }
    }
}
