﻿using System;
using System.Text;
using DotNetty.Buffers;
using DotNetty.Codecs.Mqtt.Packets;
using DotNetty.Transport.Channels;
using DotNetty.Transport.Channels.Groups;

namespace MQTT.Server
{
    public class EchoHandler : ChannelHandlerAdapter
    {
        //接收数据
        public override void ChannelRead(IChannelHandlerContext context, object message)
        {
            Console.WriteLine("Received from client...");
            var buffer = message as Packet;
            Console.WriteLine("PacketTyp=" + buffer.PacketType);
            if (buffer != null)
            {
                if (buffer is ConnectPacket)
                {
                    Console.WriteLine("Connect from mqtt client,id=: " + ((ConnectPacket)buffer).ClientId);
                    context.WriteAndFlushAsync(new ConnAckPacket
                    {
                        ReturnCode = ConnectReturnCode.Accepted,
                        SessionPresent = true
                    });//写入输出流

                    
                }
                else
                {
                    context.WriteAndFlushAsync(new PublishPacket(QualityOfService.ExactlyOnce, false, false)
                    {
                        PacketId = 33,
                        TopicName = "test2",
                        Payload = Unpooled.WrappedBuffer(Encoding.UTF8.GetBytes("message from server"))
                    });//写入输出流
                }
            }
        }


        //异常事件
        public override void ExceptionCaught(IChannelHandlerContext context, Exception exception)
        {
            Console.WriteLine("ExceptionCaught " + context.Channel.Id);
            context.CloseAsync();

        }

        //客户端断开连接事件
        public override void ChannelInactive(IChannelHandlerContext context)
        {
            context.CloseAsync();
            Console.WriteLine("ChannelInactive " + context.Channel.Id);
        }

    }


}
