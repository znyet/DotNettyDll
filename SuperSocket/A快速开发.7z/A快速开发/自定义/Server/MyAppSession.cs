﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SuperSocket.SocketBase;

namespace TestSuperSocket3
{
    public class MyAppSession : AppSession<MyAppSession, MyRequestInfo>
    {
    }
}
