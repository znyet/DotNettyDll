﻿using DotNetty.Codecs.Mqtt;
using DotNetty.Transport.Bootstrapping;
using DotNetty.Transport.Channels;
using DotNetty.Transport.Channels.Sockets;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MQTT.Server
{
    class Program
    {
        static IEventLoopGroup serverGroup;
        static IEventLoopGroup workerGroup;
        static IChannel serverChannel;
        static ServerBootstrap serverBootstrap;
        static int port = 8123;

        static void Main(string[] args)
        {

            serverBootstrap = new ServerBootstrap();

            serverGroup = new MultithreadEventLoopGroup(Environment.ProcessorCount / 2);
            workerGroup = new MultithreadEventLoopGroup();
            serverBootstrap.Channel<TcpServerSocketChannel>();

            serverBootstrap
              .Group(serverGroup, workerGroup)
              .Option(ChannelOption.TcpNodelay, true)
              .ChildHandler(new ActionChannelInitializer<IChannel>(channel =>
              {
                  IChannelPipeline pip = channel.Pipeline;
                  pip.AddLast("decoder", new MqttDecoder(true, 256 * 1024));
                  pip.AddLast("encoder", new MqttEncoder());
                  pip.AddLast(new EchoHandler());
              }));

            //serverChannel = serverBootstrap.BindAsync(ipAddress, port).Result; 
            serverChannel = serverBootstrap.BindAsync(port).Result;
            Console.WriteLine("server start listen in port " + port);

            Console.ReadKey();



        }
    }
}
